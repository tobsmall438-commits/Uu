# Shadow City - Android project

## Build the APK in the cloud (no Android Studio needed)
1. Create a free GitHub account and a new repository.
2. Upload ALL files of this folder (keep the folder structure, including the hidden .github folder).
3. Open the Actions tab -> "Build APK" -> wait ~5 minutes.
4. Download the ShadowCity-APK artifact, unzip, copy app-debug.apk to the phone, install (allow unknown sources).

## Build locally
1. Run: bash fetch_libs.sh
2. Open the folder in Android Studio -> Build -> Build APK(s).

Not tested on a device yet.
