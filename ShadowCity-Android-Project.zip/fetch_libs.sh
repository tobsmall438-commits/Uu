#!/bin/bash
# Downloads three.js and post-processing scripts into the app assets (needs internet, run once)
set -e
D=app/src/main/assets/lib; mkdir -p $D
curl -fsSL -o $D/three.min.js https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js
for f in shaders/CopyShader shaders/LuminosityHighPassShader shaders/FXAAShader postprocessing/EffectComposer postprocessing/RenderPass postprocessing/ShaderPass postprocessing/UnrealBloomPass; do
  curl -fsSL -o $D/$(basename $f).js https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/$f.js
done
echo done
